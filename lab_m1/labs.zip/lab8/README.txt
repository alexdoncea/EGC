Stiu ca am trimis dupa deadline si ca nu se puncteaza, dar am vrut sa stiu daca
implementarea este totusi cea dorita si nu are probleme. Multumesc!